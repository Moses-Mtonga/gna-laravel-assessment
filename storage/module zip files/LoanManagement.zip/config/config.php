<?php

return [
    'name' => 'LoanManagement',
];
